<?php
/*
Plugin Name: Trebnie Bookmarks
Plugin URI: https://www.trebnie.nl/ict-tips/wordpress/wordpress-plugin-trebnies-bookmarks/
Description: Easy way to add all your favorite bookmarks to your WordPress site. And you can easily list all bookmarks at once or by category in an article or post. Each click increments that URL's counter, making it easy to see how many times a URL has been clicked.
Version: 1.0.12
Author: Bert Nieuwenampsen
Author URI: https://www.trebnie.nl
Text Domain: Add all you favorite sites and display them in an article or post
	Show all bookmarks
		[trebnie_bookmarks]

	Show only category 'Search Engines'
		[trebnie_bookmarks cat="Search Engine"]

*/

# --== Variable ==--
#	TBM = Trebnie Bookmarks	
	define( 'TBM_PLUGINNAME', 'Trebnie Bookmarks');
	define( 'TBM_PLUGINNAME_PLAIN', 'trebnie_bookmarks');
	define( 'TBM_PLUGIN_VERSION', '1.0.12');
	define( 'TBM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

# --== Includes ==--
	wp_enqueue_style( 'my-plugin-styles', plugins_url( 'css/tbm-style.css', __FILE__ ), array(), '1.0' );

# --== Frontpage Shortcode ==--
	/*`
	with shortcode you can display this in a post or article
	*/
	// test met arguments
	function tbm_load_shortcode($atts) {
		include_once( TBM_PLUGIN_DIR. 'includes/tbm-shortcode.php' );
		return(tbm_load_bookmark($atts));
	}
	echo add_shortcode( TBM_PLUGINNAME_PLAIN, 'tbm_load_shortcode' );

# --== Load Admin ==--
	function tbm_admin_plugin_menu() {
		add_menu_page(TBM_PLUGINNAME, TBM_PLUGINNAME, 'manage_options', TBM_PLUGINNAME_PLAIN, 'tbm_load_admin',plugins_url( 'img/trebnie_bookmark_icon.jpg', __FILE__ ),);
	}

	function tbm_load_admin() {
		require_once( TBM_PLUGIN_DIR. 'includes/tbm-admin.php' );
	}
	add_action('admin_menu', 'tbm_admin_plugin_menu');

# --== Install SQL ==--
	function tbm_sql_install() {
		require_once( TBM_PLUGIN_DIR. 'includes/tbm-sql-install.php' );
	}

	function tbm_sql_drop() {
		require_once( TBM_PLUGIN_DIR. 'includes/tbm-sql-drop.php' );
	}

	register_activation_hook( __FILE__, 'includes/tbm_sql_install' );
	register_uninstall_hook( __FILE__, 'includes/tbm_sql_drop' );
	// register_deactivation_hook( __FILE__, 'includes/tbm_sql_drop' );	# used during development
?>
