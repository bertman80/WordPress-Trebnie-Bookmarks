<?php
/*
Trebnie Bookmarks Admin Module

Plugin URI: https://www.trebnie.nl/ict-tips/wordpress/wordpress-plugin-trebnies-bookmarks/
Description: Easy way to add all your favorite bookmarks to your WordPress site. And you can easily list all bookmarks at once or by category in an article or post. Each click increments that URL's counter, making it easy to see how many times a URL has been clicked.
Version: 1.0.12
Author: Bert Nieuwenampsen
Author URI: https://www.trebnie.nl
*/

global $wpdb;
$table_name = $wpdb->prefix . 'trebnie_bookmarks';
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

# --== Update Record ==--
if(isset($_POST['update'])){
    $name = htmlspecialchars($_POST["name"]);
    $url = htmlspecialchars($_POST["url"]);
    $description = htmlspecialchars($_POST["description"]);
    $category = htmlspecialchars($_POST["category"]);
    $target = $_POST["target"];
	$enable = "0";
	if(isset($_POST['enable'])) {
		$enable = "1";
	}
    $id = $_POST["id"];
	
    $sql = "UPDATE $table_name SET name='$name',url='$url',description='$description',category='$category',target='$target',enable=$enable WHERE id=$id";
	$wpdb->prepare($sql);
	$wpdb->query($sql);
}
# --== Reset Hits ==--
if(isset($_POST['reset'])){
    $id = $_POST["id"];
	
    $sql = "UPDATE $table_name SET hits=0 WHERE id=$id";
	$wpdb->prepare($sql);
	$wpdb->query($sql);
}
# --== Add New Record ==--
if(isset($_POST['add'])){
    $name = htmlspecialchars($_POST["name"]);
    $url = htmlspecialchars($_POST["url"]);
    $description = htmlspecialchars($_POST["description"]);
    $category = htmlspecialchars($_POST["category"]);
    $target = $_POST["target"];
	$enable = "0";
	if(isset($_POST['enable'])) {
		$enable = "1";
	}

	$sql = "INSERT INTO $table_name (name, url, description, category, target, enable) VALUES 
	('$name', '$url', '$description', '$category', '$target', $enable)";
	$tmp = $wpdb->prepare($sql);
	$wpdb->query( $tmp );
}
# --== Delete Record ==--
if(isset($_POST['delete'])){
    $id = $_POST["id"];

    $sql = "DELETE FROM $table_name WHERE id=$id";
	$wpdb->query( $sql );
}

# --== Site ==--
echo "<h1>" .TBM_PLUGINNAME. " Admin</h1>
Current pluginverion: " .TBM_PLUGIN_VERSION. "<br>
For tips, bugs and ideas, go to: <a href='https://www.trebnie.nl/ict-tips/wordpress/wordpress-plugin-trebnies-bookmarks' target='_blank'>Bert's Site</a><p>

<tmb_header>How to use</tmb_header><br>
Show all bookmarks in a article or post.<br>
<b>[trebnie_bookmarks]</b><br>
Show only one category in a article or post<br>";
echo '<b>[trebnie_bookmarks cat="Search Engine"]</b><br><hr>';

# --== Add New Bookmark ==-
$target = array("_blank","_self");	# Variable used in new and existing targets
$catlist = $wpdb->get_results("SELECT distinct category FROM $table_name ORDER BY category");

$test = "www.google.nl";
// echo $test-?link;
echo filter_var($test, FILTER_VALIDATE_URL);

echo "<tmb_header>Add new bookmark</tmb_header>";
echo "
<table class=tbm_backend>
	<tr>
        <td width=250px>Name</td>
        <td width=250px>URL</td>
        <td width=250px>Description</td>
        <td width=200px>Category</td>
        <td width=120px>Target</td>
        <td width=60px>Enable</td>
        <td width=60px></td>
	</tr>";

echo "
	<tr>
		<form method='post'>
			<td><input style='width:100%' type='text' id='name' name='name'></td>
			<td><input style='width:100%' type='text' id='url' name='url'></td>
			<td><input style='width:100%' type='text' id='description' name='description'</td>
			<td><input style='width:100%' list='cats' type='text' id='category' name='category'>
				<datalist id='cats'>
				";
				foreach ($catlist as $catrow) {
					echo "<option value='".$catrow->category."'>";
				}
			echo "
				</datalist>
			</td>
			<td>
				<select style='width:100%' id='target' name='target'>";
					foreach ($target as $trg) {
						if ($trg == "_blank") {
							echo "<option value='$trg' selected>$trg</option>";
						} else {
							echo "<option value='$trg'>$trg</option>";
						}
					}
			echo "				
				</select>
			</td>
			<td align='center'><input type='checkbox' id='enable' name='enable' checked></td>

			<td><input style='width:100%' type='submit' name='add' value='add'></td>
		</form>
	</tr>
";

echo "
</table>";

# --== Existing Bookmarks ==-
echo "<tmb_header>Existing bookmarks</tmb_header>";
$results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY category, name");
$currentcat = "";

	echo "
    <table class=tbm_backend>
    <tr>
        <td width=250px>Name</td>
        <td width=250px>URL</td>
        <td width=250px>Description</td>
        <td width=200px>Category</td>
        <td width=120px>Target</td>
        <td width=30px>Enable</td>
        <td width=30px>Hits</td>
        <td width=60px></td>
        <td width=60px></td>
        <td width=60px></td>
    </tr>";
	
foreach($results as $row) {
	echo "
    <tr>
		<form method='post'>
			<td><input style='width:100%' type='text' id='name' name='name' value='".$row->name."'></td>
			<td><input style='width:100%' type='text' id='url' name='url' value='".$row->url."'></td>
			<td><input style='width:100%' type='text' id='description' name='description' value='".$row->description."'></td>
			<td><input style='width:100%' type='text' id='category' name='category' value='".$row->category."'></td>
			<td>
				<select style='width:100%' id='target' name='target'>";
					foreach ($target as $trg) {
						if ($trg == $row->target) {
							echo "<option value='$trg' selected>$trg</option>";
						} else {
							echo "<option value='$trg'>$trg</option>";
						}
					}
		echo "				
				</select>
			</td>
			<td align='center'>";
				if ($row->enable == '1') {
					echo "<input type='checkbox' id='enable' name='enable' checked>";
				} else {
					echo "<input type='checkbox' id='enable' name='enable'>";
				}
		echo "
			</td>
			<td>".$row->hits. "</td>
			<input type='hidden' name='id' id='id' value='".$row->id. "'>

			<td><input style='width:100%' type='submit' name='update' value='update'></td>
			<td><input style='width:100%' type='submit' name='delete' value='delete'></td>
			<td><input style='width:100%' type='submit' name='reset' value='reset hits'></td>
		</form>
    </tr>
    ";
}	
echo "
    </table>";
	
	// echo "<input style='width:250px' type='text' id='target' name='target' value='".$row->target."'>";

?>
