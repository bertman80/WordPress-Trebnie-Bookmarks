<?php
/*
Trebnie Bookmarks Create SQL Table

Plugin URI: https://www.trebnie.nl/ict-tips/wordpress/wordpress-plugin-trebnies-bookmarks/
Description: Easy way to add all your favorite bookmarks to your WordPress site. And you can easily list all bookmarks at once or by category in an article or post. Each click increments that URL's counter, making it easy to see how many times a URL has been clicked.
Version: 1.0.12
Author: Bert Nieuwenampsen
Author URI: https://www.trebnie.nl
*/

# Create Table		
global $wpdb;
$table_name = $wpdb->prefix . 'trebnie_bookmarks';
$charset_collate = $wpdb->get_charset_collate();

$sql = "CREATE TABLE $table_name (
	id int NOT NULL AUTO_INCREMENT,
	name varchar(50),
	url text,
	description text,
	category varchar(50),
	target varchar(10),
	enable bit(1),
	hits int(11) default 0,
	PRIMARY KEY  (id)
) $charset_collate;";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );

# Insert Example Data
$sql = "INSERT INTO $table_name (name, url, description, category, target, enable) VALUES 
('Google', 'https://www.google.com', 'Is one of the biggest search engine', 'Search Engine', '_blank', '1'), 
('Bing', 'https://www.bing.com', 'Microsoft Bing (commonly known as Bing) is a web search engine owned and operated by Microsoft.', 'Search Engine', '_blank', '1'),
('Duck Duck Go', 'https://duckduckgo.com', 'The Internet privacy company that empowers you to seamlessly take control of your personal information online, without any tradeoffs.', 'Search Engine', '_blank', '1'),
('Facebook', 'https://www.facebook.com', 'Facebook is an online social media and social networking service owned by American company Meta Platforms.', 'Social Media', '_blank', '1'),
('Twitter', 'https://www.twitter.com', 'Twitter is an online social media and social networking service owned and operated by American company Twitter, Inc.', 'Social Media', '_blank', '1'),
('Instagram', 'https://www.instagram.com', 'Instagram is a photo and video sharing social networking service owned by American company Meta Platforms.', 'Social Media', '_blank', '1'),
('-= Trebnie =-', 'https://www.trebnie.nl', 'The personal site of the author.', 'World Wide', '_blank', '1')
";

dbDelta( $sql );

# --== Set Version ==--
update_option( TBM_PLUGINNAME_PLAIN, TBM_PLUGIN_VERSION );
?>