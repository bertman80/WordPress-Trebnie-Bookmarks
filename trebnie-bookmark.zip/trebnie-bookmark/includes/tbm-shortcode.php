<?php
/*
Trebnie Bookmarks Frontpage Module

Plugin URI: https://www.trebnie.nl/ict-tips/wordpress/wordpress-plugin-trebnies-bookmarks
Description: Easy way to add all your favorite bookmarks to your WordPress site. And you can easily list all bookmarks at once or by category in an article or post. Each click increments that URL's counter, making it easy to see how many times a URL has been clicked.
Version: 1.0.12
Author: Bert Nieuwenampsen
Author URI: https://www.trebnie.nl
*/

# --== Counter ==--
if(isset($_GET["tmb_link"])) {
	global $wpdb;
	$id =$_GET["tmb_link"];
	$table_name = $wpdb->prefix . 'trebnie_bookmarks';

	$sql = "select url from $table_name where id=$id and enable='1'";
	$results = $wpdb->get_results($sql);
	if($wpdb->num_rows>0) {
		$url = $results[0]->url;
		
		if (substr($url, 0, 4) !== "http") {
			$url = "https://$url";
		}

		$sql = "UPDATE $table_name SET hits=hits+1 WHERE id=$id ;";
		$wpdb->prepare($sql);
		$wpdb->query($sql);

		?>
		<script type='text/javascript'>
			window.open('<?php echo $url; ?>','_self');
		</script>
		<?php
	}
}

function tbm_load_bookmark($atts) {
	# --== Loading ==--
	if (isset($atts['cat'])) {
		$cat = $atts['cat'];
	}
	
	global $wpdb;
	$table_name = $wpdb->prefix . 'trebnie_bookmarks';

	$sql = "select * from $table_name where enable='1' order by category, name";
	if (isset($cat)) {
		$sql = "select * from $table_name where enable='1' and category='$cat' order by category, name";	
	}
	$results = $wpdb->get_results($sql);
	$currentcat = "";
	$site = "";
	
	# --== Building Site ==-
	$site = "$site
		<table class=tbm_frontend>";
		
	foreach($results as $row) {
		$cat = $row->category;
		if ($currentcat <> $cat) {
			$currentcat = $cat;
			$site = "$site
				<thead>
					<tr>
						<td class='tbm-header' colspan='2'><strong>$cat</strong></td>
					</tr>
				</thead>
				<tbody>
				";	
		}
			$site = "$site
				<tr class='bookmark'>
					<td width=150px valign='top'>
						<a href='?tmb_link=" .$row->id. "' target=" .$row->target. " rel='noreferrer noopener'>" .$row->name. "</a>
					</td>
					<td>
						" .$row->description. "
					</td>
				</tr>
				";
	}

	$site = "$site
			</tbody>
		</table>
	";
	
	return $site;
}

?>