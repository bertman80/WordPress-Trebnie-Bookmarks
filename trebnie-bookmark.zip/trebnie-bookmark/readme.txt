=== Trebnie Bookmark ===
Contributors: trebnie
Donate link: https://www.trebnie.nl/ict-tips/wordpress/wordpress-plugin-trebnies-bookmarks/
Tags: Bookmark,Favorite,Website
Tested up to: 6.1.1
Stable tag: 6.1.1
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
A simple plugin to display youre favorite sites in total or by catagory in an article or short.

== Description ==
With this plugin you can simply add, remove, disable or update a bookmark on your site. You can display just to add this to your
article or post.
Easy way to add all your favorite bookmarks to your WordPress site.
Each click increments that URL's counter, making it easy to see how many times a URL has been clicked.

	Show all bookmarks
		[trebnie_bookmarks]

	Show only category 'Search Engines'
		[trebnie_bookmarks cat="Search Engine"]

== Frequently Asked Questions ==
= Future improvements =
A counter on the links, just to see if its being clicked

== Screenshots ==
The color depends on you theme
Logo: trebnie_bookmark-logo.png
Frontend: trebnie_bookmark_frontend.png
Howto: trebnie_bookmark_howto.png
Admin: trebnie_bookmark_admin.png

== Changelog ==
1.0.9: feb 2023
	TBM = Trebnie Bookmarks
	All function renamed added trebnie_bookmark
	Excapt the main file all file are renamed

1.0.10: feb 2023
	Every click will increase a hit number
	
1.0.11: feb 2023
	add https:// on clicked link