<?php
/*
Trebnie Bookmarks Removes SQL Table

Plugin URI: https://www.trebnie.nl/ict-tips/wordpress/wordpress-plugin-trebnies-bookmarks/
Description: Easy way to add all your favorite bookmarks to your WordPress site. And you can easily list all bookmarks at once or by category in an article or post. Each click increments that URL's counter, making it easy to see how many times a URL has been clicked.
Version: 1.0.11
Author: Bert Nieuwenampsen
Author URI: https://www.trebnie.nl
*/

global $wpdb;
$table_name = $wpdb->prefix . 'trebnie_bookmarks';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

# --== Set Version ==--
// update_option( TBM_PLUGINNAME_PLAIN, "x" );
$sql = "DELETE FROM wp_options where option_name = '" .TBM_PLUGINNAME_PLAIN. "'";
$wpdb->query( $sql );

?>